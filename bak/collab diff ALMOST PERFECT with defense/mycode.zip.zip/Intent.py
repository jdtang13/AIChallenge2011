class Intent:
    WAIT = 0
    GATHER = 1
    CONQUER = 2
    KILL = 3
    EXPLORE = 4
    DEFEND = 5
        
